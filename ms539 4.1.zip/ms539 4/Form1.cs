﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ms539_4
{
    public partial class Form1 : Form
    {
        private Random random = new Random();
        

        public Form1()
        {
            InitializeComponent();
            btnGenerate.Click += new EventHandler(btnGenerate_Click);
            listBox1.SelectedIndexChanged += new EventHandler(listBox1_SelectedIndexChanged);
            progressBar1.Maximum = 100000;

            // Add items to listBox1
            listBox1.Items.Add("A");
            listBox1.Items.Add("B");
            listBox1.Items.Add("C");
            listBox1.Items.Add("D");
            listBox1.Items.Add("E");
            listBox1.Items.Add("F");
            listBox1.Items.Add("G");

            // Initialize and set properties for txtUserInput
            
            // Set other properties if needed (e.g., Size, Location, etc.)
            // ...

            // Add txtUserInput to the form's Controls collection
            
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            int randomNumber = random.Next(1, 201);
            string message = GetMessageForNumber(randomNumber);
            lblResult.Text = $"Random Number: {randomNumber}, {message}";

            // Update progress bar
            int feet;
            
            {
              
            }

            // Write the results to a file
            WriteToFile($"Random Number: {randomNumber}, {message}");
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedMenu = listBox1.SelectedItem?.ToString();
            if (!string.IsNullOrEmpty(selectedMenu))
            {
                string locationMessage = GetLocationForMenu(selectedMenu);
                MessageBox.Show(locationMessage, $"Menu {selectedMenu} Locations");
            }
        }

        private string GetMessageForNumber(int randomNumber)
        {
            if (randomNumber >= 1 && randomNumber <= 25)
            {
                return "Menu A";
            }
            else if (randomNumber >= 26 && randomNumber <= 50)
            {
                return "Menu B";
            }
            else if (randomNumber >= 51 && randomNumber <= 75)
            {
                return "Menu C";
            }
            else if (randomNumber >= 76 && randomNumber <= 100)
            {
                return "Menu D";
            }
            else if (randomNumber >= 101 && randomNumber <= 150)
            {
                return "Menu E";
            }
            else if (randomNumber >= 151 && randomNumber <= 175)
            {
                return "Menu F";
            }
            else if (randomNumber >= 176 && randomNumber <= 200)
            {
                return "Menu G";
            }
            return "";
        }

        private string GetLocationForMenu(string menu)
        {
            switch (menu)
            {
                case "A":
                    return "Keystone, Breckenridge, WinterPark";
                case "B":
                    return "Vail, Cooper";
                case "C":
                    return "Beavercreek, Aspen";
                case "D":
                    return "Steamboat, Eldora";
                case "E":
                    return "Butte, Wolfcreek, Monarch";
                case "F":
                    return "Loveland, ABay";
                case "G":
                    return "Backcountry";
                default:
                    return "";
            }
        }

        private void WriteToFile(string content)
        {
            string filePath = "output.txt";
            using (StreamWriter writer = new StreamWriter(filePath, true))
            {
                writer.WriteLine(content);
            }
        }
    }
}